# Project - Maze Runner Robot

## 1. Environment Setup

heyyyyyyy so the vibe is i have setup the enviroenmet with a basic maze structure so far with the turtlebot 3, its like exactly like our 3 scenarios for quiz 2 just for a basic structure. Step 1 and 2 remain the same from the old readme. i've  written a bsic readme to just says what the files do and how to test it basically, it even shows the graphs on tensorboard :;.

### Step 1: Create a Virtual Environment

For Linux / macOS:
```bash
# Create a virtual environment named "venv"
python -m venv venv

# Activate the virtual environment
source venv/bin/activate
```

For Windows
```bash
# Create a virtual environment named "venv"
python -m venv venv

# Activate the virtual environment
venv\Scripts\activate
```

### Step 2: Install Dependencies

**Option A: Standard Installation (CPU only / Mac)**
```bash
pip install gymnasium pybullet stable-baselines3[extra] numpy matplotlib
```

**Option B: training on GPU  (NVIDIA only)**
If you have an NVIDIA card and want faster multi-threaded PPO training, install the CUDA version of PyTorch first, and then install the rest:
```bash
# Note: Check the exact PyTorch version for your CUDA toolkit on pytorch.org
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install gymnasium pybullet stable-baselines3[extra] numpy matplotlib
```

---

## 2. Code Layout

**Model Folder**
- loads the zip you trained

**Turtlebot_description/meshes**
- all the meshes needed for the turtlebot including urdfs and the dae sensor stuff
    - but the burger urdf file separate cause thats how file layout works so far yur

**metrics_callback**
- loads other graph titles on tensorboard i think just to give more metric data based off our training

**turtlebot3_max_env**
- builds the environment and lowkey has code we can move to train file later one 
    - had rewards and penalties stuff like that 


---

## 3. how to test

# run main system
python maze.py

# Train
python maze_train.py

# Test (after training)
python maze_test.py

# Monitor training
tensorboard --logdir maze_tensorboard